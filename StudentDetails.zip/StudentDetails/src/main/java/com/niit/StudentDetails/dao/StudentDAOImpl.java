package com.niit.StudentDetails.dao;


import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.StudentDetails.model.Student;

@Repository("studentDAO")
public class StudentDAOImpl implements StudentDAO {
	
	

	@Autowired
	private SessionFactory sessionFactory;


	public StudentDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public List<Student> list() {
		@SuppressWarnings("unchecked")
		List<Student> listCategory = (List<Student>) sessionFactory.getCurrentSession()
				.createCriteria(Student.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();

		return listCategory;
	}

	@Transactional
	public void saveOrUpdate(Student student) {
		sessionFactory.getCurrentSession().saveOrUpdate(student);
	}

	@Transactional
	public void delete(String id) {
		Student StudentToDelete = new Student();
		StudentToDelete.setId(id);
		sessionFactory.getCurrentSession().delete(StudentToDelete);
	}

	@Transactional
	public Student get(String id) {
		String hql = "from Category where id=" + id;
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		
		@SuppressWarnings("unchecked")
		List<Student> listCategory = (List<Student>) query.list();
		
		if (listCategory != null && !listCategory.isEmpty()) {
			return listCategory.get(0);
		}
		
		return null;
	}

	public boolean isValidUser(String id, String name, String description) {
		// TODO Auto-generated method stub
		return false;
	}


}
